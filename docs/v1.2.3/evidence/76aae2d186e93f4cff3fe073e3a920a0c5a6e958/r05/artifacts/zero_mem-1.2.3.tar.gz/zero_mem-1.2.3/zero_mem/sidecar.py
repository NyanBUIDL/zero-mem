"""Transport-neutral local sidecar dispatcher with fail-closed boundaries."""
from __future__ import annotations

import dataclasses
import json
import time
import warnings
from dataclasses import dataclass
from enum import Enum
from typing import Any, Mapping

from .api import PublicClient
from src.integration.sidecar import SidecarConfig as CanonicalSidecarConfig, ZeroMemSidecar

CONTRACT_VERSION = "1.1"
CAPABILITIES = (
    "observe", "sync", "health", "capabilities",
    "search", "get_trace", "get_task_state", "get_decisions",
)
CANONICAL_READ_CAPABILITIES = ("search", "get_trace", "get_task_state", "get_decisions")
DEPRECATION_MESSAGE = (
    "zero_mem.sidecar.LocalSidecar is deprecated; use "
    "src.integration.sidecar.ZeroMemSidecar for the canonical bounded sidecar contract"
)


class SidecarError(RuntimeError):
    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


@dataclass(frozen=True)
class SidecarConfig:
    max_payload_bytes: int = 64 * 1024
    deadline_seconds: float = 5.0


class LocalSidecar:
    """Deprecated compatibility wrapper; canonical transport is ``ZeroMemSidecar``."""

    def __init__(self, client: PublicClient, *, config: SidecarConfig | None = None) -> None:
        warnings.warn(DEPRECATION_MESSAGE, DeprecationWarning, stacklevel=2)
        self._client = client
        self._config = config or SidecarConfig()
        if self._config.max_payload_bytes < 1 or self._config.deadline_seconds <= 0:
            raise SidecarError("CONFIG_INVALID")
        self._started = False
        self._canonical: ZeroMemSidecar | None = None

    def _canonical_dispatch(self, payload: dict[str, Any]) -> dict[str, Any]:
        tool = payload["tool"]
        request = {key: value for key, value in payload.items() if key != "tool"}
        result = getattr(self._client, tool)(request)
        def public_item(item: Any) -> Any:
            if isinstance(item, Enum):
                return item.value
            if dataclasses.is_dataclass(item) and not isinstance(item, type):
                return public_item(dataclasses.asdict(item))
            if isinstance(item, Mapping):
                return {str(key): public_item(value) for key, value in item.items()}
            if isinstance(item, (list, tuple)):
                return [public_item(value) for value in item]
            return item

        return {
            "capability": f"zero_mem.{tool}",
            "status": getattr(result, "status", "UNAVAILABLE"),
            "reason_code": getattr(result, "reason_code", "READ_UNAVAILABLE"),
            "items": [public_item(item) for item in (getattr(result, "items", ()) or ())],
            "provenance": public_item(list(getattr(result, "provenance", ()) or ())),
            "freshness": public_item(getattr(result, "freshness", None)),
        }

    def _canonical_handle(self, request: dict[str, Any]) -> dict[str, Any]:
        if self._canonical is None:
            raise SidecarError("UNAVAILABLE")
        payload = dict(request)
        payload["tool"] = payload.pop("capability")
        identity = payload.pop("identity")
        result = self._canonical.handle(
            json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
            identity=identity,
        )
        if result.status.value != "OK":
            raise SidecarError(result.status.value)
        return result.payload

    def start(self) -> dict[str, Any]:
        if self._started:
            return self.health()
        self._canonical = ZeroMemSidecar(
            CanonicalSidecarConfig(
                max_request_bytes=self._config.max_payload_bytes,
                default_deadline=self._config.deadline_seconds,
            ),
            dispatcher=self._canonical_dispatch,
        )
        self._started = True
        return self.health()

    def stop(self) -> dict[str, Any]:
        self._started = False
        if self._canonical is not None:
            self._canonical.close()
            self._canonical = None
        return {"status": "STOPPED", "contract_version": CONTRACT_VERSION}

    def health(self) -> dict[str, Any]:
        return {"status": "READY" if self._started else "STOPPED", "contract_version": CONTRACT_VERSION, "transport": "embedded-local"}

    def dispatch(self, request: dict[str, Any]) -> dict[str, Any]:
        if not self._started:
            raise SidecarError("UNAVAILABLE")
        if not isinstance(request, dict) or not isinstance(request.get("identity"), str) or not request["identity"]:
            raise SidecarError("IDENTITY_REQUIRED")
        try:
            size = len(json.dumps(request, ensure_ascii=False).encode("utf-8"))
        except (TypeError, ValueError):
            raise SidecarError("INVALID_REQUEST") from None
        if size > self._config.max_payload_bytes:
            raise SidecarError("PAYLOAD_TOO_LARGE")
        capability = request.get("capability")
        if capability in CANONICAL_READ_CAPABILITIES:
            return self._canonical_handle(request)
        if capability not in CAPABILITIES:
            raise SidecarError("CAPABILITY_UNSUPPORTED")
        started = time.monotonic()
        if capability == "capabilities":
            result: Any = {"capabilities": list(CAPABILITIES), "contract_version": CONTRACT_VERSION}
        elif capability == "health":
            result = self.health()
        elif capability == "sync":
            result = self._client.sync()
        else:
            result = self._client.observe_message(request.get("payload"))
        if time.monotonic() - started > self._config.deadline_seconds:
            raise SidecarError("DEADLINE_EXCEEDED")
        return {"ok": True, "capability": capability, "result": result}


__all__ = ["CAPABILITIES", "CONTRACT_VERSION", "DEPRECATION_MESSAGE", "LocalSidecar", "SidecarConfig", "SidecarError"]
